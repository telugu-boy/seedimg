# seedimg
~~This currently requires libpng to be installed with vcpkg on Windows.~~

libpng is automatically installed through nuget. All contributors are encouraged to use nuget for image format libraries until cmake is set up.
